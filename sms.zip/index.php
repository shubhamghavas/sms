<?php 

header("location:admin/homepage.php");
?>