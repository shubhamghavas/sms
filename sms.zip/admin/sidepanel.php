<div id="loading"></div>
 <div class="side-nav expand-lg " >
   <div class="side-nav-inner">
      <ul class="side-nav-menu scrollable">
      <li class="side-nav-header">
      </li>
      <li class="nav-item dropdown open">
         
         <a href="index_page.php">
            <span class="icon-holder"> 
            <i class="fa fa-tachometer"  style="color: white;" aria-hidden="true"></i> 
            </span>
            <span class="title" style="color: white;">Dashboard</span>
            <!-- <span class="arrow">
               <i class="mdi mdi-chevron-right"></i>
               </span> -->
         </a>
      </li>
      <li class="nav-item dropdown">
         <a class="dropdown-toggle" href="javascript:void(0);">
         <span class="icon-holder">
         <i class="fa fa-user"  style="color: white;" aria-hidden="true"></i> 
         </span>
         <span class="title"  style="color: white;">Staff Advisor</span>
         <span style="color: white;"class="arrow">
         <i class="mdi mdi-chevron-right"></i>
         </span>
         </a>
         <ul  class="dropdown-menu">
            <li>
               <a  style="color: white;" href="staffadvisor.php"> Add Staff Advisors Details</a>
            </li>
            <li>
               <a  style="color: white;" href="factable.php">Manage Staff Advisors</a>
            </li>
         </ul>
      </li>

      <li class="nav-item dropdown">
         <a class="dropdown-toggle" href="javascript:void(0);">
         <span class="icon-holder">
         <i class="fa fa-user"  style="color: white;" aria-hidden="true"></i> 
         </span>
         <span class="title"  style="color: white;">Co-Staff Advisor</span>
         <span style="color: white;"class="arrow">
         <i class="mdi mdi-chevron-right"></i>
         </span>
         </a>
         <ul  class="dropdown-menu">
            <li>
               <a  style="color: white;" href="csa.php"> Add Co-Staff Advisor Details</a>
            </li>
            <li>
               <a  style="color: white;" href="csatable.php">Manage Co-Staff Advisor</a>
            </li>
         </ul>
      </li>

      <li class="nav-item dropdown">
         <a class="dropdown-toggle" href="javascript:void(0);">
         <span class="icon-holder">
         <i class="fa fa-user"  style="color: white;" aria-hidden="true"></i> 
         </span>
         <span class="title"  style="color: white;">Gymkhana Incharge</span>
         <span style="color: white;"class="arrow">
         <i class="mdi mdi-chevron-right"></i>
         </span>
         </a>
         <ul  class="dropdown-menu">
            <li>
               <a  style="color: white;" href="gi.php"> Add Gymkhana Incharge Details</a>
            </li>
            <li>
               <a  style="color: white;" href="gitable.php">Manage Gymkhana Incharge</a>
            </li>
         </ul>
      </li>

      <li class="nav-item dropdown">
         <a class="dropdown-toggle" href="javascript:void(0);">
         <span class="icon-holder">
         <i class="fa fa-user"  style="color: white;" aria-hidden="true"></i> 
         </span>
         <span class="title"  style="color: white;">Gymkhana Coordinator</span>
         <span style="color: white;"class="arrow">
         <i class="mdi mdi-chevron-right"></i>
         </span>
         </a>
         <ul  class="dropdown-menu">
            <li>
               <a  style="color: white;" href="gc.php"> Add Gymkhana Coordinator Details</a>
            </li>
            <li>
               <a  style="color: white;" href="gctable.php">Manage Gymkhana Coordinator</a>
            </li>
         </ul>
      </li>

      <li class="nav-item dropdown">
         <a class="dropdown-toggle" href="javascript:void(0);">
         <span class="icon-holder">
         <i class="fa fa-user"  style="color: white;" aria-hidden="true"></i> 
         </span>
         <span class="title"  style="color: white;">Physical Directors</span>
         <span style="color: white;"class="arrow">
         <i class="mdi mdi-chevron-right"></i>
         </span>
         </a>
         <ul  class="dropdown-menu">
            <li>
               <a  style="color: white;" href="physicaldirector.php"> Add physical directors</a>
            </li>
            <li>
               <a  style="color: white;" href="physicaldirectortable.php">Manage physical directors</a>
            </li>
         </ul>
      </li>
      <li class="nav-item dropdown">
         <a class="dropdown-toggle" href="javascript:void(0);">
            <span class="icon-holder">
            <i class="fa fa-graduation-cap"  style="color: white;"aria-hidden="true"></i>
            </span>
            <span class="title"  style="color: white;">Teams </span>
            <span style="color: white;"class="arrow">
               <i class="mdi mdi-chevron-right"></i>
               <ul class="dropdown-menu">
                  <li>
         <a  style="color: white;" href="team.php">Add Team  Details</a>
         </li>
         <li>
         <a  style="color: white;" href="schtable.php">Manage Teams </a>
         </li>
         </ul>
         </span>
         </a>
      </li>
      <li class="nav-item dropdown">
         <a class="dropdown-toggle" href="javascript:void(0);">
         <span class="icon-holder">
         <span  style="color: white;"class="ti-game"></span>
         </span>
         <span class="title"  style="color: white;">Sports</span>
         <span style="color: white;" class="arrow">
         <i class="mdi mdi-chevron-right"></i>
         </span>
         </a>
         <ul class="dropdown-menu">
            <li>
               <a  style="color: white;" href="sportdetails.php">Add Sport Details</a>
            </li>
            <li>
               <a  style="color: white;"href="sportdetailstable.php">Manage Sports</a>
            </li>
            <!--  <li>
               <a href="">Game Mode</a>
               </li> -->
         </ul>
      </li>
      <li class="nav-item dropdown">
         <a class="dropdown-toggle" href="javascript:void(0);">
         <span class="icon-holder">
         <i  style="color: white;"class="fa fa-users" aria-hidden="true"></i>
         </span>
         <span   style="color: white;"class="title">Players</span>
         <span style="color: white;"class="arrow">
         <i class="mdi mdi-chevron-right"></i>
         </span>
         </a>
         <ul class="dropdown-menu">
            <li>
               <a  style="color: white;"href="player.php">Add Player Details</a>
            </li>
            <li>
               <a  style="color: white;" href=" playertable.php">Manage Players</a>
            </li>
            <!-- <li>
               <a href="mulplayer.php ">Add Multiple Players</a>
               </li> -->
         </ul>
      </li>
      <li class="nav-item dropdown">
         <a class="dropdown-toggle" href="javascript:void(0);">
         <span class="icon-holder">
         <i  style="color: white;"class="fa fa-fw"></i>
         </span>
         <span  style="color: white;"class="title">Tournaments</span>
         <span style="color: white;"class="arrow">
         <i class="mdi mdi-chevron-right"></i>
         </span>
         </a>
         <ul class="dropdown-menu">
            <li>
               <a  style="color: white;" href="tournament.php ">Add Tournament Details</a>
            </li>
            <li>
               <a  style="color: white;" href="tournamenttable.php ">Manage Tournaments</a>
            </li>
            <li>
               <a  style="color: white;" href="result.php ">Declare Result</a>
            </li>
            <li>
               <a  style="color: white;" href="resulttable.php ">Manage Results</a>
            </li>
         </ul>
      </li>

      <li class="nav-item dropdown">
         <a class="dropdown-toggle" href="javascript:void(0);">
         <span class="icon-holder">
         <i  style="color: white;"class="fa fa-users" aria-hidden="true"></i>
         </span>
         <span   style="color: white;"class="title">Viewers</span>
         <span style="color: white;"class="arrow">
         <i class="mdi mdi-chevron-right"></i>
         </span>
         </a>
         <ul class="dropdown-menu">
            <li>
               <a  style="color: white;"href="viewer.php">Add Viewer Details</a>
            </li>
            <li>
               <a  style="color: white;" href=" viewertable.php">Manage Viewers</a>
            </li>
            <!-- <li>
               <a href="mulplayer.php ">Add Multiple Players</a>
               </li> -->
         </ul>
      </li>

      <li class="nav-item dropdown">
         <a class="dropdown-toggle" href="javascript:void(0);">
         <span class="icon-holder">
         <i  style="color: white;"class="fa fa-users" aria-hidden="true"></i>
         </span>
         <span   style="color: white;"class="title">Documents</span>
         <span style="color: white;"class="arrow">
         <i class="mdi mdi-chevron-right"></i>
         </span>
         </a>
         <ul class="dropdown-menu">
            <li>
               <a  style="color: white;"href="upload.php">Add Documents</a>
            </li>
            <!-- <li>
               <a href="mulplayer.php ">Add Multiple Players</a>
               </li> -->
         </ul>
      </li>

      <li class="nav-item dropdown">
         <a class="dropdown-toggle" href="javascript:void(0);">
         <span class="icon-holder">
         <i  style="color: white;"class="fa fa-users" aria-hidden="true"></i>
         </span>
         <span   style="color: white;"class="title">Recruitment</span>
         <span style="color: white;"class="arrow">
         <i class="mdi mdi-chevron-right"></i>
         </span>
         </a>
         <ul class="dropdown-menu">
            <li>
               <a  style="color: white;"href="requirements.php">Add Recruitments</a>
            </li>

            <li>
               <a  style="color: white;"href="requirementstable.php">Manage Recruitment</a>
            </li>
           
         </ul>
      </li>

      <li class="nav-item dropdown">
         <a class="dropdown-toggle" href="javascript:void(0);">
         <span class="icon-holder">
         <i  style="color: white;"class="fa fa-users" aria-hidden="true"></i>
         </span>
         <span   style="color: white;"class="title">Equipment Requirement </span>
         <span style="color: white;"class="arrow">
         <i class="mdi mdi-chevron-right"></i>
         </span>
         </a>
         <ul class="dropdown-menu">
            <li>
               <a  style="color: white;"href="ir.php">Add Sport Equipment Requirement </a>
            </li>

            <li>
               <a  style="color: white;"href="irtable.php">Manage Sport Equipment Requirement</a>
            </li>
           
         </ul>
      </li>

       
      <li class="nav-item dropdown">
         <!-- <a class="dropdown-toggle" href="javascript:void(0);"> -->
         <a  style="color: white;" href="search.php">   
         <span class="icon-holder">
         <i  style="color: white;" class="fa fa-search" aria-hidden="true"></i> 
         </span>
         <span  style="color: white;" class="title" >Search</span>
         </a>
      </li>
      <li class="nav-item dropdown">
         <!-- <a class="dropdown-toggle" href="javascript:void(0);"> -->
         <a  style="color: white;" href="report.php">
            <span class="icon-holder">
            <span style="color: white;" class="ti-files"></span>
            </span>
            <span  style="color: white;" class="title" >Reports</span>
            <!-- <span class="arrow" >
               <i class="mdi mdi-chevron-right" ></i>
               </span> -->
         </a>
         <!-- <ul class="dropdown-menu">
            <li>
                <a href="report.php"> Date-Wise Report</a>
            </li>
            </ul>    --> 
      </li>
   </div>
</div>