<?php
   // session_start();
   
    include '../assets/constant/config.php';
    try {
           $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
           $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
          
               
           }catch(PDOException $e)
           {
           echo "Connection failed: " . $e->getMessage(); exit;
           }
    ?>
<?php include("header.php");?>
<?php include("sidepanel.php");?>
<html>
   <body>
      <div class="page-container">
         <div class="main-content">
            <div class="container-fluid">
               <div class="card">
                  <div class="card-body">
                     <h1 class="header-title">Add Gymkhana Incharge Details</h1>
                     <div class="row m-v-30">
                        <div class="col-10 offset-1 col-sm-8 offset-sm-2">
                           <div class="p-v-25">
                              <form method="POST" action="app/gicrud.php">
                            
                              
                                 <div class="row">
                                   

                                 
                                    <div class="col-md-6">
                                       <div class="form-group">
                                          <label class="control-label">Gymkhana Incharge Name </label>
                                          <input type="text" class="form-control" name="name" placeholder="Enter Gymkhana Incharge Name">
                                       </div>
                                    </div>

                                    <div class="col-md-6">
                                       <div class="form-group">
                                          <label class="control-label">Select Gymkhana Incharge Department</label>
                                          <select  class="xyz form-control form-control-lg "name="dname" class=xyz>
                                             <option> ---Select Department---</option>
                                             
                                             <option>CSE   </option>
                                             <option>IT </option>
                                             <option>ELECTRICAL  </option>
                                             <option>ELECTRONICS  </option>
                                             <option>MECHANICAL  </option>
                                             <option>CIVIL  </option>
                                          </select>
                                       </div>
                                    </div>

                                    <div class="col-md-6">
                                       <div class="form-group" >
                                          <label class="control-label" >Gender</label>
                                          <br>
                                          <input type="radio" name="gender" value="Male" class="mr-2">Male<br>
                                          <input type="radio" name="gender" value="Female" class="mr-2">Female
                                          <br>
                                       </div>
                                    </div>
                                    
                                    <div class="col-md-6">
                                       <div class="form-group">
                                          <label class="control-label">Address</label>
                                          <input type="text" class="form-control"   name="address" placeholder="Enter Address"  aria-required="true">
                                       </div>
                                    </div>
                                    <div class="col-md-6">
                                       <div class="form-group">
                                          <label class="control-label">Contact</label>
                                          <input type="contact" class="form-control" pattern="^[0][1-9]\d{9}$|^[1-9]\d{9}$"  name="contact" placeholder="Enter contact">
                                       </div>
                                    </div>
                                    <div class="col-md-6">
                                       <div class="form-group">
                                          <label class="control-label">Email</label>
                                          <input type="text" class="form-control"   name="email" placeholder="Enter Email">
                                       </div>
                                    </div>
                                    <div class="col-md-6">
                                       <div class="form-group">
                                          <label class="control-label">Academic Year</label>
                                          <input type="text" class="form-control"   name="ay" placeholder="Enter Academic Year">
                                       </div>
                                    </div>
                                    <br>
                                    <br>
                                 </div>
                                 <br>
                                 <br>
                                 <br>
                                 <br>
                                 <button name="submit"class="btn btn-success btn-lg">Submit</button>
                              </form>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </body>
</html>
      <?php include("footer.php");?>
  