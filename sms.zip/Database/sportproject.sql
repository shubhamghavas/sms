-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 22, 2022 at 01:58 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sportproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `changepas`
--

CREATE TABLE `changepas` (
  `opass` varchar(150) NOT NULL,
  `npass` varchar(150) NOT NULL,
  `cpass` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `facilitator`
--

CREATE TABLE `facilitator` (
  `id` int(11) NOT NULL,
  `faccode` varchar(20) NOT NULL,
  `name` text NOT NULL,
  `gender` varchar(20) NOT NULL,
  `address` varchar(50) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `delete_status` tinyint(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `facilitator`
--

INSERT INTO `facilitator` (`id`, `faccode`, `name`, `gender`, `address`, `contact`, `delete_status`) VALUES
(1, 'FACI-001', 'Mr Saurabh Patil', 'Male', 'Sujay Apartment,Canada Corner,Nashik', '9090909090', 0),
(2, 'FACI-002', 'Mr Yashodhan Joshi ', 'Male', 'Galaxy Apartment,Ashoka Marg,Nashik', '7070707070', 0),
(3, 'FACI-003', 'Rohit Patil', 'Male', 'Nashik', '9854748596', 0),
(4, 'FACI-004', 'Raj Varma', 'Male', 'Mumbai', '8574859685', 0);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `uname` varchar(15) NOT NULL,
  `pass` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `physicaldirector`
--

CREATE TABLE `physicaldirector` (
  `id` int(11) NOT NULL,
  `fdcode` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `address` varchar(50) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `delete_status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `physicaldirector`
--

INSERT INTO `physicaldirector` (`id`, `fdcode`, `name`, `gender`, `address`, `contact`, `delete_status`) VALUES
(1, 'PHYS-001', 'Radha', 'Female', '23, vasant vihar, ojar ', '9090909090', 0),
(2, 'PHYS-002', 'raghini', 'Female', '14, ojar ', '4562312523', 0);

-- --------------------------------------------------------

--
-- Table structure for table `player`
--

CREATE TABLE `player` (
  `id` int(11) NOT NULL,
  `playercode` varchar(20) NOT NULL,
  `name` text NOT NULL,
  `page` int(20) NOT NULL,
  `pcourse` varchar(20) NOT NULL,
  `padd` varchar(50) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `school` varchar(50) NOT NULL,
  `sportname` varchar(20) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `delete_status` tinyint(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `player`
--

INSERT INTO `player` (`id`, `playercode`, `name`, `page`, `pcourse`, `padd`, `gender`, `school`, `sportname`, `contact`, `delete_status`) VALUES
(1, 'PLYR-01', 'Gauri Tajane', 25, 'BSC', 'Shriram Nagar,Nashik', 'Female', 'Excel Public School', 'Running', '6060606060', 0),
(2, 'PLYR-02', 'Akash Sharma', 27, 'BBA', 'CIDCO Colony,Mumbai', 'Male', 'Orchid International School', 'Cricket', '7070707070', 0);

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE `profile` (
  `id` int(20) NOT NULL,
  `uname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mob` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `result`
--

CREATE TABLE `result` (
  `id` int(11) NOT NULL,
  `tname` text NOT NULL,
  `result_school` varchar(100) NOT NULL,
  `rank` varchar(50) NOT NULL,
  `delete_status` tinyint(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `result`
--

INSERT INTO `result` (`id`, `tname`, `result_school`, `rank`, `delete_status`) VALUES
(1, 'ICC Cricket World Cup', 'Excel Public School', 'Winner', 0),
(2, 'ICC Cricket World Cup', 'Orchid International School', 'Looser', 0),
(3, 'ICC Cricket World Cup', 'Orchid International School', 'Third Price', 0),
(4, 'dsfgt', 'Orchid International School', 'First Price', 0);

-- --------------------------------------------------------

--
-- Table structure for table `school`
--

CREATE TABLE `school` (
  `id` int(11) NOT NULL,
  `scode` varchar(25) NOT NULL,
  `sname` text NOT NULL,
  `saddress` varchar(50) NOT NULL,
  `school_state` varchar(30) NOT NULL,
  `sgrade` text NOT NULL,
  `r_status` int(20) NOT NULL,
  `delete_status` tinyint(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `school`
--

INSERT INTO `school` (`id`, `scode`, `sname`, `saddress`, `school_state`, `sgrade`, `r_status`, `delete_status`) VALUES
(1, 'SCHOOL001', 'Excel Public School', 'Delhi', 'Maharashtra', 'A', 0, 0),
(2, 'SCHOOL002', 'Orchid International School', 'Surat', 'Maharashtra', 'B', 0, 0),
(3, 'TEAM003', 'ssfdhd', 'shivaji nagar,ojhar,nashik', 'Andaman and Nicobar ', 'a', 0, 0),
(4, 'TEAM004', 'Excel Public Team', 'shivaji nagar,ojhar,nashik', 'Andaman and Nicobar ', 'A', 0, 0),
(5, 'TEAM005', 'Orchid International', 'shivaji nagar,ojhar,nashik', 'Andhra Pradesh', 'A', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `id` int(20) NOT NULL,
  `uname` text NOT NULL,
  `email` varchar(50) NOT NULL,
  `mob` varchar(10) NOT NULL,
  `pass` varchar(150) NOT NULL,
  `cpass` varchar(150) NOT NULL,
  `photo` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`id`, `uname`, `email`, `mob`, `pass`, `cpass`, `photo`) VALUES
(6, 'Mayuri K.', 'mayuri.infospace@gmail.com', '9523230459', 'aa7f019c326413d5b8bcad4314228bcd33ef557f5d81c7cc977f7728156f4357', 'aa7f019c326413d5b8bcad4314228bcd33ef557f5d81c7cc977f7728156f4357', 'thumb-8.jpg'),
(7, 'Manasi Borade', 'manasi@gmail.com', '8745968745', '0aefaf76154859002c9db8542bbefe60caca45ccef0a6a79634bae0edafdfa27', '0390024610415f44c9d5ca4a01dd96bb09fc95e6450bfd740a9a4cf4abcc8130', 'thumb-8.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `sportdetails`
--

CREATE TABLE `sportdetails` (
  `id` int(11) NOT NULL,
  `sportcode` varchar(20) NOT NULL,
  `name` varchar(25) NOT NULL,
  `sporttype` varchar(20) NOT NULL,
  `gametype` varchar(20) NOT NULL,
  `numofplayers` int(11) NOT NULL,
  `annualbudget` varchar(20) NOT NULL,
  `delete_status` tinyint(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sportdetails`
--

INSERT INTO `sportdetails` (`id`, `sportcode`, `name`, `sporttype`, `gametype`, `numofplayers`, `annualbudget`, `delete_status`) VALUES
(1, 'SPORT011', 'Cricket', 'TEAM', 'PER QUARTER', 11, '20000', 0),
(2, 'SPORT012', 'Running', 'SINGLE', 'PER METER', 1, '50000', 0),
(3, 'SPORT013', 'Badminton', 'DOUBLE', 'PER QUARTER', 2, '', 1),
(4, 'SPORT014', 'Soccer', 'SINGLE', 'PER METER', 12, '50000', 0);

-- --------------------------------------------------------

--
-- Table structure for table `sport_name`
--

CREATE TABLE `sport_name` (
  `name` varchar(100) NOT NULL,
  `delete_status` tinyint(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sport_name`
--

INSERT INTO `sport_name` (`name`, `delete_status`) VALUES
('Soccer', 0),
('Basketball', 0),
('Tennis', 0),
('Baseball', 0),
('Golf', 0),
('Running', 0),
('Volleyball', 0),
('Badminton', 0),
('Swimming', 0),
('Boxing', 0),
('Table tennis', 0),
('Skiing', 0),
('Ice skating', 0),
('Running', 0),
('Roller skating', 0),
('Cricket', 0),
('Rugby', 0),
('Pool', 0),
('Darts', 0),
('Football', 0),
('Bowling', 0),
('Ice hockey', 0),
('Surfing', 0),
('Karate', 0),
('Horse racing', 0),
('Snowboarding', 0),
('Skateboarding', 0),
('Cycling', 0),
('Archery', 0),
('Fishing', 0),
('Gymnastics', 0),
('Figure skating', 0),
('Rock climbing', 0),
('Sumo wrestling', 0),
('Taekwondo', 0),
('Fencing', 0),
('Water skiing', 0),
('Jet skiing', 0),
('Weight lifting', 0),
('Scuba diving', 0),
('Judo', 0),
('Wind surfing', 0),
('Kickboxing', 0),
('Sky diving', 0),
('Hang gliding', 0),
('Bungee jumping', 0);

-- --------------------------------------------------------

--
-- Table structure for table `state`
--

CREATE TABLE `state` (
  `school_state` varchar(30) NOT NULL,
  `delete_status` tinyint(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `state`
--

INSERT INTO `state` (`school_state`, `delete_status`) VALUES
('Andaman and Nicobar ', 0),
('Andhra Pradesh', 0),
('Arunachal Pradesh', 0),
('Assam', 0),
('Bihar', 0),
('Chandigarh', 0),
('Chhattisgarh', 0),
('Dadra and Nagar Have', 0),
('Daman and Diu', 0),
('Delhi-NCR', 0),
('Goa', 0),
('Gujarat', 0),
('Haryana', 0),
('Himachal Pradesh', 0),
('Jammu and Kashmir', 0),
('Jharkhand', 0),
('Karnataka', 0),
('Kenmore', 0),
('Kerala', 0),
('Lakshadweep', 0),
('Madhya Pradesh', 0),
('Maharashtra', 0),
('Manipur', 0),
('Meghalaya', 0),
('Mizoram', 0),
('Nagaland', 0),
('Narora', 0),
('Natwar', 0),
('Odisha', 0),
('Paschim Medinipur', 0),
('Pondicherry', 0),
('Punjab', 0),
('Rajasthan', 0),
('Sikkim', 0),
('Tamil Nadu', 0),
('Telangana', 0),
('Tripura', 0),
('TEST', 0),
('UP-1', 0),
('xxxxxx', 0),
('West Bengal', 0),
('UP-2', 0),
('Arunachal Pradesh', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tournament`
--

CREATE TABLE `tournament` (
  `id` int(11) NOT NULL,
  `tname` text NOT NULL,
  `ttype` varchar(30) NOT NULL,
  `sport` varchar(30) NOT NULL,
  `name` text NOT NULL,
  `pname` varchar(50) NOT NULL,
  `venue` text NOT NULL,
  `date` date NOT NULL,
  `stime` time(6) NOT NULL,
  `etime` time(6) NOT NULL,
  `status` text NOT NULL,
  `delete_status` tinyint(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tournament`
--

INSERT INTO `tournament` (`id`, `tname`, `ttype`, `sport`, `name`, `pname`, `venue`, `date`, `stime`, `etime`, `status`, `delete_status`) VALUES
(1, 'ICC Cricket World Cup', 'Single League', 'Cricket', 'Mr Yashodhan Joshi ', 'Radha', 'CGMSC COURT', '2021-10-13', '09:45:00.000000', '20:55:00.000000', 'Championship', 0),
(2, 'hj', 'hjg', 'Running', '----Select Facilitator Name----', '', '', '0000-00-00', '00:00:00.000000', '00:00:00.000000', '', 1),
(3, 'jvhk', 'ghc', 'Running', 'Mr Yashodhan Joshi ', '', 'ghcc', '2022-05-11', '17:50:00.000000', '15:52:00.000000', 'gfxkxf', 1),
(4, 'dsfgt', 'gfh', 'Cricket', 'Mr Saurabh Patil', 'raghini', 'bhj', '2022-09-21', '21:58:00.000000', '22:59:00.000000', 'cvbgnhg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `viewer`
--

CREATE TABLE `viewer` (
  `id` int(11) NOT NULL,
  `viewercode` varchar(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `image` varchar(50) NOT NULL,
  `delete_status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `viewer`
--

INSERT INTO `viewer` (`id`, `viewercode`, `name`, `gender`, `email`, `password`, `mobile`, `image`, `delete_status`) VALUES
(1, 'VIEW-001', 'Maithili Verma', 'Female', 'maithili@gmail.com', 'fdc16d3f30f4a032df336d2887ab064f9d8cdd5e0292ae7018db6e39b3ee73da', '8080505022', 'gs5nq5dthipbqfiisa4m.jpg', 0),
(2, 'VIEW-002', 'Suraj Pande', 'Male', 'suraj.pande@gmail.com', 'aa946af0203c3dd45142bcdd1e0853be3e37d6fa0bcf774b92bb1bb695f35ec2', '9090908888', 'thumb-2.jpg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `web_management`
--

CREATE TABLE `web_management` (
  `id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `favicon` varchar(100) NOT NULL,
  `footer` varchar(100) NOT NULL,
  `site_key` varchar(100) NOT NULL,
  `secret_key` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `web_management`
--

INSERT INTO `web_management` (`id`, `title`, `favicon`, `footer`, `site_key`, `secret_key`) VALUES
(1, 'First Project Theme', '', 'Sport Management System', '6LdJC4AeAAAAAE638ShRfVSMBDSDjbQmkxD-lh_p', '6LdJC4AeAAAAAMLn9tfGX8_BoZGIwLHgBNiiYgxb');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `facilitator`
--
ALTER TABLE `facilitator`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `physicaldirector`
--
ALTER TABLE `physicaldirector`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `player`
--
ALTER TABLE `player`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `profile`
--
ALTER TABLE `profile`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `result`
--
ALTER TABLE `result`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `school`
--
ALTER TABLE `school`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sportdetails`
--
ALTER TABLE `sportdetails`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tournament`
--
ALTER TABLE `tournament`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `viewer`
--
ALTER TABLE `viewer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `web_management`
--
ALTER TABLE `web_management`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `facilitator`
--
ALTER TABLE `facilitator`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `physicaldirector`
--
ALTER TABLE `physicaldirector`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `player`
--
ALTER TABLE `player`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `profile`
--
ALTER TABLE `profile`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `result`
--
ALTER TABLE `result`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `school`
--
ALTER TABLE `school`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `signup`
--
ALTER TABLE `signup`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `sportdetails`
--
ALTER TABLE `sportdetails`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tournament`
--
ALTER TABLE `tournament`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `viewer`
--
ALTER TABLE `viewer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `web_management`
--
ALTER TABLE `web_management`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
