<?php include("header.php"); ?>
<?php include("sidepanel.php"); ?>

<div class="page-container dashboard ">
   <div class="main-content">
      <div class="container-fluid">
        
         <br><br><br>
         <!-- <div class="card"> -->
            <div class="page-header">
               <br>
               <br>
               <div class="media">
                  <div class="col-sm-3">
                     <div class="card">
                        <div class="box border bottom" style="background-color:#E91E63;">
                           <div class="card-body">
                              <div class="media justify-content-between">
                                 <div>
                                    <h5>
                                       <p class="" style="color:white;"><b> TOTAL STAFF ADVISORS</b></p>
                                    </h5>
                                    <?php
                                       $stmt=$conn->prepare("SELECT count(*) as cnt_id from  facilitator where delete_status='0'");
                                       $stmt->execute();
                                       $record=$stmt->fetch(PDO::FETCH_ASSOC);
                                       // echo $record['cnt_id'];
                                       ?>
                                    <span style="color:black;"class="text-semibold text-white font-size-40"><?php echo $record['cnt_id'];
                                       ?></span> 
                                 </div>
                                 <div class="align-self-end">
                                    <i class="fa fa-users font-size-90 icon-gradient-white  text-white" ></i>
                                    <!--  <i class="ti-bar-chart font-size-90 icon-gradient-white  text-white"></i> -->
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>

                  

                  

                  <div class="col-sm-3">
                     <div class="card">
                        <div class="box border bottom" style="background-color:#4CAF50 ;">
                           <div class="card-body">
                              <div class="media justify-content-between">
                                 <div>
                                    <h5>
                                       <p class="" style="color:white;"><b>TEAM PARTICIPANTS</b></p>
                                    </h5>
                                    <?php
                                       $stmt=$conn->prepare("SELECT count(*) as cnt_sname from  school where delete_status='0'");
                                       $stmt->execute();
                                       $record=$stmt->fetch(PDO::FETCH_ASSOC);
                                       // echo $record['cnt_school'];
                                        ?> 
                                    <span style="color:black;"class="text-semibold text-white font-size-40"><?php echo $record['cnt_sname'];
                                       ?></span> 
                                 </div>
                                 <div class="align-self-end">
                                    <i class="fa fa-graduation-cap font-size-90 icon-gradient-white  text-white" ></i>
                                    <!--  <i class="ti-bar-chart font-size-90 icon-gradient-white  text-white"></i> -->
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>

                  <div class="col-sm-3">
                     <div class="card">
                        <div class="box border bottom" style="background-color:#FF9800;">
                           <div class="card-body">
                              <div class="media justify-content-between">
                                 <div>
                                    <h5>
                                       <p class="" style="color:white;"><b>TOTAL RESULTS</b></p>
                                    </h5>
                                    <?php
                                       $stmt=$conn->prepare("SELECT count(*) as cnt_id from  result where delete_status='0'");
                                       $stmt->execute();
                                       $record=$stmt->fetch(PDO::FETCH_ASSOC);
                                       // echo $record['cnt_id'];
                                        ?>
                                    <span style="color:black;"class="text-semibold text-white font-size-40"><?php echo $record['cnt_id'];
                                       ?></span> 
                                 </div>
                                 <div class="align-self-end">
                                    <span class="ti-medall-alt font-size-100 icon-gradient-white  text-white"></span>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>

                  <div class="col-sm-3">
                     <div class="card">
                        <div class="box border bottom" style="background-color:#FF5722;">
                           <div class="card-body">
                              <div class="media justify-content-between">
                                 <div>
                                    <h5>
                                       <p class="" style="color:white;"><b>TOTAL PLAYERS</b></p>
                                    </h5>
                                    <?php
                                       $stmt=$conn->prepare("SELECT count(*) as cnt_id from  player where delete_status='0'");
                                       $stmt->execute();
                                       $record=$stmt->fetch(PDO::FETCH_ASSOC);
                                       // echo $record['cnt_id'];
                                        ?>
                                    <span style="color:black;"class="text-semibold text-white font-size-40"><?php echo $record['cnt_id'];
                                       ?></span> 
                                 </div>
                                 <div class="align-self-end">
                                    <i class="fa fa-users font-size-90 icon-gradient-white  text-white" ></i>
                                    <!--  <i class="ti-bar-chart font-size-90 icon-gradient-white  text-white"></i> -->
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>

               <div class="col-sm-3">
                  <div class="card">
                     <div class="box border bottom" style="background-color:#3F51B5;">
                        <div class="card-body">
                           <div class="media justify-content-between">
                              <div>
                                 <h5>
                                    <p class="" style="color:white;"><b>TOTAL TOURNAMENTS</b></p>
                                 </h5>
                                 <?php
                                    $stmt=$conn->prepare("SELECT count(*) as cnt_id from tournament where delete_status='0'");
                                    $stmt->execute();
                                    $record=$stmt->fetch(PDO::FETCH_ASSOC);
                                    // echo $record['cnt_id'];
                                     ?>
                                 <span style="color:black;"class="text-semibold text-white font-size-40"><?php echo $record['cnt_id'];
                                    ?></span>
                              </div>
                              <div class="align-self-end">
                                 <i class="fa fa-fw font-size-90 icon-gradient-white  text-white" aria-hidden="true" title="Copy to use trophy"></i>
                               
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>

               
            </div>
         </div>
      </div>
       <?php include("footer.php"); ?>
   </div>
  


