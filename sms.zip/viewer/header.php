

<!DOCTYPE html>

<?php 
//session_start();
include("checklogin.php");


 include '../assets/constant/config.php';
 try {
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        }catch(PDOException $e)
        {
        echo "Connection failed: " . $e->getMessage();
        }
        $stmt=$conn->prepare(" SELECT * from viewer WHERE id='".$_SESSION['uid']."'");
        $stmt->execute();
                $record=$stmt->fetchAll();
                foreach($record as $key) { ?>



    

<head>
     <?php
            $stmt=$conn->prepare("SELECT * from `web_management`");
            $stmt->execute();
            $record1=$stmt->fetchAll();
      ?>
    <?php foreach($record1 as $rec){?>

    <link href="../assets/css/select2.css" rel="stylesheet" />
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title> WCE Sports Management System</title>
                                             
    
     
                                             
                                             
   


    <!-- Favicon -->
    <link rel="apple-touch-icon" href="../assets/images/logo/apple-touch-icon.png">
    <link rel="shortcut icon" href="../assets/images/logo/<?php echo $rec['favicon'];?>">

    <!-- core dependcies css -->
    <link rel="stylesheet" href="../assets/vendor/bootstrap/dist/css/bootstrap.css" />
   <!--  <link rel="stylesheet" href="../assets/vendor/PACE/themes/blue/pace-theme-minimal.css" /> -->
    <link rel="stylesheet" href="../assets/vendor/perfect-scrollbar/css/perfect-scrollbar.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- page css -->

    <!-- core css -->
  <!--   <link href="../assets/css/font-awesome.min.css" rel="stylesheet"> -->
    <link href="../assets/css/themify-icons.css" rel="stylesheet">
    <link href="../assets/css/materialdesignicons.min.css" rel="stylesheet">
    <link href="../assets/css/animate.min.css" rel="stylesheet">
    <link href="../assets/css/app.css" rel="stylesheet">
    <link href="../assets/css/popup_style.css" rel="stylesheet">
    <!-- css -->
    
<link href="https://cdn.datatables.net/1.11.4/css/jquery.dataTables.min.css" rel="stylesheet">
<link href="https://cdn.datatables.net/buttons/2.2.2/css/buttons.dataTables.min.css" rel="stylesheet">
<?php } ?>

</head>

<body>



    <div class="app header-success-gradient">
        <div class="layout">
            <!-- Header START -->
            <div class="header navbar dashboard "  id="page">
                <div class="header-container">
                  
                    
                    <ul class="nav-right">
                        <li class="dropdown dropdown-animated scale-left">
                            <a href="" class="dropdown-toggle" data-toggle="dropdown">
                              <!--   <i class="mdi mdi-apps"></i> -->
                            </a>
                           
                        </li>
                      
                            <ul class="dropdown-menu dropdown-lg p-v-0">
                                <li class="p-v-15 p-h-20 border bottom text-dark">
                                    <h5 class="m-b-0">
                                        <i class="mdi mdi-bell-ring-outline p-r-10"></i>
                                        <span>Notifications</span>
                                    </h5>
                                </li>
                                <li>
                                    <ul class="list-media overflow-y-auto relative scrollable" style="max-height: 300px">
                                        <li class="list-item border bottom">
                                            <a href="javascript:void(0);" class="media-hover p-15">
                                                <div class="media-img">
                                                    <div class="icon-avatar bg-primary">
                                                        <i class="ti-settings"></i>
                                                    </div>
                                                </div>
                                                <div class="info">
                                                    <span class="title">
                                                        System shutdown
                                                    </span>
                                                    <span class="sub-title">8 min ago</span>
                                                </div>
                                            </a>
                                        </li>
                                        <li class="list-item border bottom">
                                            <a href="javascript:void(0);" class="media-hover p-15">
                                                <div class="media-img">
                                                    <div class="icon-avatar bg-success">
                                                        <i class="ti-user"></i>
                                                    </div>
                                                </div>
                                                <div class="info">
                                                    <span class="title">
                                                        New User Registered
                                                    </span>
                                                    <span class="sub-title">12 min ago</span>
                                                </div>
                                            </a>
                                        </li>
                                        <li class="list-item border bottom">
                                            <a href="javascript:void(0);" class="media-hover p-15">
                                                <div class="media-img">
                                                    <div class="icon-avatar bg-warning">
                                                        <i class="ti-file"></i>
                                                    </div>
                                                </div>
                                                <div class="info">
                                                    <span class="title">
                                                        New Attacthemnet
                                                    </span>
                                                    <span class="sub-title">12 min ago</span>
                                                </div>
                                            </a>
                                        </li>
                                        <li class="list-item border bottom">
                                            <a href="javascript:void(0);" class="media-hover p-15">
                                                <div class="media-img">
                                                    <div class="icon-avatar bg-info">
                                                        <i class="ti-shopping-cart"></i>
                                                    </div>
                                                </div>
                                                <div class="info">
                                                    <span class="title">
                                                        New Order Received
                                                    </span>
                                                    <span class="sub-title">12 min ago</span>
                                                </div>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="p-v-15 p-h-20 text-center">
                                    <span>
                                        <a href="" class="text-gray">Check all notifications <i class="ei-right-chevron p-l-5 font-size-10"></i></a>
                                    </span>
                                </li>
                            </ul>
                        </li>
                        <li class="user-profile dropdown dropdown-animated scale-left">
                            <a href="" class="dropdown-toggle" data-toggle="dropdown">
                                <img class="profile-img img-fluid" src="../assets/images/avatars/<?php echo $key['image'];?>" alt="">
                            </a>
                            <ul class="dropdown-menu dropdown-md p-v-0">
                                <li>
                                    <ul class="list-media">
                                        <li class="list-item p-15">
                                          
                                            <div class="media-img">
                                                <img src=" ../assets/images/avatars/<?php echo $key['image'];?> " alt="">
                                            </div> 
                                            <div class="info">
                                                <span class="title text-semibold"><?php echo $key['name'];?></span>
                                                <span class="sub-title">Viewer</span>
                                            </div>
                                        </li>
                                    </ul>
                                </li>
                                <li role="separator" class="divider"></li>
                               <!--  <li>
                                    <a href="">
                                        <i class="ti-settings p-r-10"></i>
                                        <span>Setting</span>
                                    </a>
                                </li> -->
                                <li>
                                    <a href="profile_page.php">
                                        <i class="ti-user p-r-10"></i>
                                        <span>Profile</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="changepassword.php">


                                        
                                     <span class="ti-key"></span>
                                        <span>change password</span>
                                        <span class="badge badge-pill badge-success pull-right"></span>
                                    </a>
                                </li>
                               <!--  <li>
                                    <a href="">
                                        <i class="ti-email p-r-10"></i>
                                        <span>Inbox</span>
                                        <span class="badge badge-pill badge-success pull-right">2</span>
                                    </a>
                                </li> -->
                                <li>
                                    <a href="logout.php">
                                        <i class="ti-power-off p-r-10"></i>
                                        <span>Logout</span>
                                    </a>
                                </li>
                           
                                
                            </ul>
                        </li>
                        <li class="m-r-10">
                            <a class="quick-view-toggler" href="javascript:void(0);">
                              <!--   <i class="mdi mdi-format-indent-decrease"></i> -->
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</body>
 <?php } ?>