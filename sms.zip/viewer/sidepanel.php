<div id="loading"></div>
 <div class="side-nav expand-lg " >
   <div class="side-nav-inner">
      <ul class="side-nav-menu scrollable">
      <li class="side-nav-header">
      </li>
      <li class="nav-item dropdown open">
         
         <a href="index_page.php">
            <span class="icon-holder"> 
            <i class="fa fa-tachometer"  style="color: white;" aria-hidden="true"></i> 
            </span>
            <span class="title" style="color: white;">Dashboard</span>
            <!-- <span class="arrow">
               <i class="mdi mdi-chevron-right"></i>
               </span> -->
         </a>
      </li>
      <li class="nav-item dropdown">
         <a class="dropdown-toggle" href="javascript:void(0);">
         <span class="icon-holder">
         <i class="fa fa-user"  style="color: white;" aria-hidden="true"></i> 
         </span>
         <span class="title"  style="color: white;">Staff Advisors</span>
         <span style="color: white;"class="arrow">
         <i class="mdi mdi-chevron-right"></i>
         </span>
         </a>
         <ul  class="dropdown-menu">
            
            <li>
               <a  style="color: white;" href="factable.php">View all Staff Advisor</a>
            </li>
         </ul>
      </li>

      <li class="nav-item dropdown">
         <a class="dropdown-toggle" href="javascript:void(0);">
         <span class="icon-holder">
         <i class="fa fa-user"  style="color: white;" aria-hidden="true"></i> 
         </span>
         <span class="title"  style="color: white;">Co-Staff Advisor</span>
         <span style="color: white;"class="arrow">
         <i class="mdi mdi-chevron-right"></i>
         </span>
         </a>
         <ul  class="dropdown-menu">
            
            <li>
               <a  style="color: white;" href="csatable.php">View all Co-Staff Advisor</a>
            </li>
         </ul>
      </li>

      <li class="nav-item dropdown">
         <a class="dropdown-toggle" href="javascript:void(0);">
         <span class="icon-holder">
         <i class="fa fa-user"  style="color: white;" aria-hidden="true"></i> 
         </span>
         <span class="title"  style="color: white;">Gymkhana Incharge</span>
         <span style="color: white;"class="arrow">
         <i class="mdi mdi-chevron-right"></i>
         </span>
         </a>
         <ul  class="dropdown-menu">
            
            <li>
               <a  style="color: white;" href="gitable.php">View Gymkhana Incharge</a>
            </li>
         </ul>
      </li>

      <li class="nav-item dropdown">
         <a class="dropdown-toggle" href="javascript:void(0);">
         <span class="icon-holder">
         <i class="fa fa-user"  style="color: white;" aria-hidden="true"></i> 
         </span>
         <span class="title"  style="color: white;">Gymkhana Coordinators</span>
         <span style="color: white;"class="arrow">
         <i class="mdi mdi-chevron-right"></i>
         </span>
         </a>
         <ul  class="dropdown-menu">
            
            <li>
               <a  style="color: white;" href="gctable.php">View all Gymkhana Coordinators</a>
            </li>
         </ul>
      </li>
      <li class="nav-item dropdown">
         <a class="dropdown-toggle" href="javascript:void(0);">
         <span class="icon-holder">
         <i class="fa fa-user"  style="color: white;" aria-hidden="true"></i> 
         </span>
         <span class="title"  style="color: white;">Physical Directors</span>
         <span style="color: white;"class="arrow">
         <i class="mdi mdi-chevron-right"></i>
         </span>
         </a>
         <ul  class="dropdown-menu">
           
            <li>
               <a  style="color: white;" href="physicaldirectortable.php">View all physical directors</a>
            </li>
         </ul>
      </li>
      <li class="nav-item dropdown">
         <a class="dropdown-toggle" href="javascript:void(0);">
            <span class="icon-holder">
            <i class="fa fa-graduation-cap"  style="color: white;"aria-hidden="true"></i>
            </span>
            <span class="title"  style="color: white;">Teams </span>
            <span style="color: white;"class="arrow">
               <i class="mdi mdi-chevron-right"></i>
               <ul class="dropdown-menu">
                  
         <li>
         <a  style="color: white;" href="schtable.php">View all Teams </a>
         </li>
         </ul>
         </span>
         </a>
      </li>
      <li class="nav-item dropdown">
         <a class="dropdown-toggle" href="javascript:void(0);">
         <span class="icon-holder">
         <span  style="color: white;"class="ti-game"></span>
         </span>
         <span class="title"  style="color: white;">Sports</span>
         <span style="color: white;" class="arrow">
         <i class="mdi mdi-chevron-right"></i>
         </span>
         </a>
         <ul class="dropdown-menu">
            
            <li>
               <a  style="color: white;"href="sportdetailstable.php">View all Sports</a>
            </li>
            <!--  <li>
               <a href="">Game Mode</a>
               </li> -->
         </ul>
      </li>
      <li class="nav-item dropdown">
         <a class="dropdown-toggle" href="javascript:void(0);">
         <span class="icon-holder">
         <i  style="color: white;"class="fa fa-users" aria-hidden="true"></i>
         </span>
         <span   style="color: white;"class="title">Players</span>
         <span style="color: white;"class="arrow">
         <i class="mdi mdi-chevron-right"></i>
         </span>
         </a>
         <ul class="dropdown-menu">
            
            <li>
               <a  style="color: white;" href=" playertable.php">View all Players</a>
            </li>
            <!-- <li>
               <a href="mulplayer.php ">Add Multiple Players</a>
               </li> -->
         </ul>
      </li>
      <li class="nav-item dropdown">
         <a class="dropdown-toggle" href="javascript:void(0);">
         <span class="icon-holder">
         <i  style="color: white;"class="fa fa-fw"></i>
         </span>
         <span  style="color: white;"class="title">Tournaments</span>
         <span style="color: white;"class="arrow">
         <i class="mdi mdi-chevron-right"></i>
         </span>
         </a>
         <ul class="dropdown-menu">
            
            <li>
               <a  style="color: white;" href="tournamenttable.php ">View all Tournaments</a>
            </li>
            
            <li>
               <a  style="color: white;" href="resulttable.php ">View Results</a>
            </li>
         </ul>
      </li>


      <li class="nav-item dropdown">
         <a class="dropdown-toggle" href="javascript:void(0);">
         <span class="icon-holder">
         <i  style="color: white;"class="fa fa-users" aria-hidden="true"></i>
         </span>
         <span   style="color: white;"class="title">Documents</span>
         <span style="color: white;"class="arrow">
         <i class="mdi mdi-chevron-right"></i>
         </span>
         </a>
         <ul class="dropdown-menu">
            <li>
               <a  style="color: white;"href="upload.php">Documents You May Need</a>
            </li>
            <!-- <li>
               <a href="mulplayer.php ">Add Multiple Players</a>
               </li> -->
         </ul>
      </li>

      <li class="nav-item dropdown">
         <a class="dropdown-toggle" href="javascript:void(0);">
         <span class="icon-holder">
         <i  style="color: white;"class="fa fa-users" aria-hidden="true"></i>
         </span>
         <span   style="color: white;"class="title">Requirements</span>
         <span style="color: white;"class="arrow">
         <i class="mdi mdi-chevron-right"></i>
         </span>
         </a>
         <ul class="dropdown-menu">
            <li>
               <a  style="color: white;"href="requirementstable.php">View All Requirements</a>
            </li>

           
         </ul>
      </li>
       
      <li class="nav-item dropdown">
         <!-- <a class="dropdown-toggle" href="javascript:void(0);"> -->
         <a  style="color: white;" href="search.php">   
         <span class="icon-holder">
         <i  style="color: white;" class="fa fa-search" aria-hidden="true"></i> 
         </span>
         <span  style="color: white;" class="title" >Search</span>
         </a>
      </li>
      <li class="nav-item dropdown">
         <!-- <a class="dropdown-toggle" href="javascript:void(0);"> -->
         <a  style="color: white;" href="report.php">
            <span class="icon-holder">
            <span style="color: white;" class="ti-files"></span>
            </span>
            <span  style="color: white;" class="title" >Reports</span>
            <!-- <span class="arrow" >
               <i class="mdi mdi-chevron-right" ></i>
               </span> -->
         </a>
         <!-- <ul class="dropdown-menu">
            <li>
                <a href="report.php"> Date-Wise Report</a>
            </li>
            </ul>    --> 
      </li>
   </div>
</div>