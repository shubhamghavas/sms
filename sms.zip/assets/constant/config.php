<?php

$servername = "localhost:4306";
$username = "root";
$password = "";
$dbname = "sms";

?>


